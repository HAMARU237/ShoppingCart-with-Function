﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            coffee = new CheckBox();
            grr = new CheckBox();
            noodle = new CheckBox();
            pizza = new CheckBox();
            oo = new CheckBox();
            rbDiscountBeverage = new CheckBox();
            rbDiscountFood = new CheckBox();
            groupBox1 = new GroupBox();
            tbGreenCoffeeQuantity = new MaskedTextBox();
            tbGreenCoffeePrice = new MaskedTextBox();
            tbCoffeeQuantity = new MaskedTextBox();
            tbCoffeePrice = new MaskedTextBox();
            groupBox2 = new GroupBox();
            tbPizzaQuantity = new MaskedTextBox();
            tbPizzaPrice = new MaskedTextBox();
            tbNoodleQuantity = new MaskedTextBox();
            tbNoodlePrice = new MaskedTextBox();
            groupBox3 = new GroupBox();
            tbDiscountFood = new MaskedTextBox();
            tbDiscountBeverage = new MaskedTextBox();
            tbDiscountAll = new MaskedTextBox();
            button1 = new Button();
            tbChange = new MaskedTextBox();
            tbCash = new MaskedTextBox();
            tbTotal = new MaskedTextBox();
            label1 = new Label();
            label3 = new Label();
            label11 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            tb01 = new MaskedTextBox();
            tb03 = new MaskedTextBox();
            tb02 = new MaskedTextBox();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            tb05 = new MaskedTextBox();
            tb04 = new MaskedTextBox();
            tb06 = new MaskedTextBox();
            label9 = new Label();
            label10 = new Label();
            tb08 = new MaskedTextBox();
            tb07 = new MaskedTextBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // coffee
            // 
            coffee.AutoSize = true;
            coffee.Location = new Point(72, 46);
            coffee.Name = "coffee";
            coffee.Size = new Size(61, 19);
            coffee.TabIndex = 0;
            coffee.Text = "Coffee";
            coffee.UseVisualStyleBackColor = true;
            // 
            // grr
            // 
            grr.AutoSize = true;
            grr.Location = new Point(72, 71);
            grr.Name = "grr";
            grr.Size = new Size(75, 19);
            grr.TabIndex = 1;
            grr.Text = "green tea";
            grr.UseVisualStyleBackColor = true;
            // 
            // noodle
            // 
            noodle.AutoSize = true;
            noodle.Location = new Point(72, 151);
            noodle.Name = "noodle";
            noodle.Size = new Size(63, 19);
            noodle.TabIndex = 2;
            noodle.Text = "noodle";
            noodle.UseVisualStyleBackColor = true;
            // 
            // pizza
            // 
            pizza.AutoSize = true;
            pizza.Location = new Point(72, 176);
            pizza.Name = "pizza";
            pizza.Size = new Size(52, 19);
            pizza.TabIndex = 3;
            pizza.Text = "pizza";
            pizza.UseVisualStyleBackColor = true;
            // 
            // oo
            // 
            oo.AutoSize = true;
            oo.Location = new Point(72, 252);
            oo.Name = "oo";
            oo.Size = new Size(38, 19);
            oo.TabIndex = 4;
            oo.Text = "all";
            oo.UseVisualStyleBackColor = true;
            // 
            // rbDiscountBeverage
            // 
            rbDiscountBeverage.AutoSize = true;
            rbDiscountBeverage.Location = new Point(72, 277);
            rbDiscountBeverage.Name = "rbDiscountBeverage";
            rbDiscountBeverage.Size = new Size(74, 19);
            rbDiscountBeverage.TabIndex = 5;
            rbDiscountBeverage.Text = "beverage";
            rbDiscountBeverage.UseVisualStyleBackColor = true;
            // 
            // rbDiscountFood
            // 
            rbDiscountFood.AutoSize = true;
            rbDiscountFood.Location = new Point(72, 302);
            rbDiscountFood.Name = "rbDiscountFood";
            rbDiscountFood.Size = new Size(51, 19);
            rbDiscountFood.TabIndex = 6;
            rbDiscountFood.Text = "food";
            rbDiscountFood.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(tbGreenCoffeeQuantity);
            groupBox1.Controls.Add(tbGreenCoffeePrice);
            groupBox1.Controls.Add(tbCoffeeQuantity);
            groupBox1.Controls.Add(tbCoffeePrice);
            groupBox1.Location = new Point(72, 28);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(384, 100);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Beverge";
            // 
            // tbGreenCoffeeQuantity
            // 
            tbGreenCoffeeQuantity.Location = new Point(241, 47);
            tbGreenCoffeeQuantity.Name = "tbGreenCoffeeQuantity";
            tbGreenCoffeeQuantity.Size = new Size(100, 23);
            tbGreenCoffeeQuantity.TabIndex = 10;
            // 
            // tbGreenCoffeePrice
            // 
            tbGreenCoffeePrice.Location = new Point(107, 46);
            tbGreenCoffeePrice.Name = "tbGreenCoffeePrice";
            tbGreenCoffeePrice.Size = new Size(100, 23);
            tbGreenCoffeePrice.TabIndex = 10;
            // 
            // tbCoffeeQuantity
            // 
            tbCoffeeQuantity.Location = new Point(241, 18);
            tbCoffeeQuantity.Name = "tbCoffeeQuantity";
            tbCoffeeQuantity.Size = new Size(100, 23);
            tbCoffeeQuantity.TabIndex = 1;
            // 
            // tbCoffeePrice
            // 
            tbCoffeePrice.Location = new Point(107, 17);
            tbCoffeePrice.Name = "tbCoffeePrice";
            tbCoffeePrice.Size = new Size(100, 23);
            tbCoffeePrice.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(tbPizzaQuantity);
            groupBox2.Controls.Add(tbPizzaPrice);
            groupBox2.Controls.Add(tbNoodleQuantity);
            groupBox2.Controls.Add(tbNoodlePrice);
            groupBox2.Location = new Point(72, 134);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(384, 100);
            groupBox2.TabIndex = 8;
            groupBox2.TabStop = false;
            groupBox2.Text = "Food";
            // 
            // tbPizzaQuantity
            // 
            tbPizzaQuantity.Location = new Point(241, 46);
            tbPizzaQuantity.Name = "tbPizzaQuantity";
            tbPizzaQuantity.Size = new Size(100, 23);
            tbPizzaQuantity.TabIndex = 10;
            // 
            // tbPizzaPrice
            // 
            tbPizzaPrice.Location = new Point(107, 44);
            tbPizzaPrice.Name = "tbPizzaPrice";
            tbPizzaPrice.Size = new Size(100, 23);
            tbPizzaPrice.TabIndex = 11;
            // 
            // tbNoodleQuantity
            // 
            tbNoodleQuantity.Location = new Point(241, 17);
            tbNoodleQuantity.Name = "tbNoodleQuantity";
            tbNoodleQuantity.Size = new Size(100, 23);
            tbNoodleQuantity.TabIndex = 11;
            // 
            // tbNoodlePrice
            // 
            tbNoodlePrice.Location = new Point(107, 15);
            tbNoodlePrice.Name = "tbNoodlePrice";
            tbNoodlePrice.Size = new Size(100, 23);
            tbNoodlePrice.TabIndex = 10;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label14);
            groupBox3.Controls.Add(label13);
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(tbDiscountFood);
            groupBox3.Controls.Add(tbDiscountBeverage);
            groupBox3.Controls.Add(tbDiscountAll);
            groupBox3.Location = new Point(72, 240);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(384, 100);
            groupBox3.TabIndex = 9;
            groupBox3.TabStop = false;
            groupBox3.Text = "Discout";
            // 
            // tbDiscountFood
            // 
            tbDiscountFood.Location = new Point(241, 68);
            tbDiscountFood.Name = "tbDiscountFood";
            tbDiscountFood.Size = new Size(100, 23);
            tbDiscountFood.TabIndex = 11;
            // 
            // tbDiscountBeverage
            // 
            tbDiscountBeverage.Location = new Point(241, 39);
            tbDiscountBeverage.Name = "tbDiscountBeverage";
            tbDiscountBeverage.Size = new Size(100, 23);
            tbDiscountBeverage.TabIndex = 12;
            // 
            // tbDiscountAll
            // 
            tbDiscountAll.Location = new Point(241, 10);
            tbDiscountAll.Name = "tbDiscountAll";
            tbDiscountAll.Size = new Size(100, 23);
            tbDiscountAll.TabIndex = 13;
            // 
            // button1
            // 
            button1.Location = new Point(504, 35);
            button1.Name = "button1";
            button1.Size = new Size(75, 306);
            button1.TabIndex = 10;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // tbChange
            // 
            tbChange.Location = new Point(714, 86);
            tbChange.Name = "tbChange";
            tbChange.Size = new Size(100, 23);
            tbChange.TabIndex = 22;
            // 
            // tbCash
            // 
            tbCash.Location = new Point(714, 57);
            tbCash.Name = "tbCash";
            tbCash.Size = new Size(100, 23);
            tbCash.TabIndex = 23;
            // 
            // tbTotal
            // 
            tbTotal.Location = new Point(714, 28);
            tbTotal.Name = "tbTotal";
            tbTotal.Size = new Size(100, 23);
            tbTotal.TabIndex = 24;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(660, 28);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 25;
            label1.Text = "total";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(660, 94);
            label3.Name = "label3";
            label3.Size = new Size(46, 15);
            label3.TabIndex = 27;
            label3.Text = "change";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(660, 60);
            label11.Name = "label11";
            label11.Size = new Size(31, 15);
            label11.TabIndex = 35;
            label11.Text = "cash";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(660, 134);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 36;
            label2.Text = "1000";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(660, 159);
            label4.Name = "label4";
            label4.Size = new Size(25, 15);
            label4.TabIndex = 37;
            label4.Text = "500";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(660, 191);
            label5.Name = "label5";
            label5.Size = new Size(25, 15);
            label5.TabIndex = 38;
            label5.Text = "100";
            // 
            // tb01
            // 
            tb01.Location = new Point(714, 131);
            tb01.Name = "tb01";
            tb01.Size = new Size(100, 23);
            tb01.TabIndex = 39;
            // 
            // tb03
            // 
            tb03.Location = new Point(714, 188);
            tb03.Name = "tb03";
            tb03.Size = new Size(100, 23);
            tb03.TabIndex = 40;
            // 
            // tb02
            // 
            tb02.Location = new Point(714, 159);
            tb02.Name = "tb02";
            tb02.Size = new Size(100, 23);
            tb02.TabIndex = 41;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(660, 228);
            label6.Name = "label6";
            label6.Size = new Size(19, 15);
            label6.TabIndex = 42;
            label6.Text = "50";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(660, 256);
            label7.Name = "label7";
            label7.Size = new Size(19, 15);
            label7.TabIndex = 43;
            label7.Text = "20";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(660, 287);
            label8.Name = "label8";
            label8.Size = new Size(19, 15);
            label8.TabIndex = 44;
            label8.Text = "10";
            // 
            // tb05
            // 
            tb05.Location = new Point(714, 257);
            tb05.Name = "tb05";
            tb05.Size = new Size(100, 23);
            tb05.TabIndex = 45;
            // 
            // tb04
            // 
            tb04.Location = new Point(714, 228);
            tb04.Name = "tb04";
            tb04.Size = new Size(100, 23);
            tb04.TabIndex = 46;
            // 
            // tb06
            // 
            tb06.Location = new Point(714, 287);
            tb06.Name = "tb06";
            tb06.Size = new Size(100, 23);
            tb06.TabIndex = 47;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(660, 351);
            label9.Name = "label9";
            label9.Size = new Size(13, 15);
            label9.TabIndex = 48;
            label9.Text = "1";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(660, 325);
            label10.Name = "label10";
            label10.Size = new Size(13, 15);
            label10.TabIndex = 49;
            label10.Text = "5";
            // 
            // tb08
            // 
            tb08.Location = new Point(714, 348);
            tb08.Name = "tb08";
            tb08.Size = new Size(100, 23);
            tb08.TabIndex = 50;
            // 
            // tb07
            // 
            tb07.Location = new Point(714, 318);
            tb07.Name = "tb07";
            tb07.Size = new Size(100, 23);
            tb07.TabIndex = 51;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(347, 16);
            label12.Name = "label12";
            label12.Size = new Size(17, 15);
            label12.TabIndex = 14;
            label12.Text = "%";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(347, 71);
            label13.Name = "label13";
            label13.Size = new Size(17, 15);
            label13.TabIndex = 15;
            label13.Text = "%";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(347, 43);
            label14.Name = "label14";
            label14.Size = new Size(17, 15);
            label14.TabIndex = 16;
            label14.Text = "%";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(959, 450);
            Controls.Add(tb07);
            Controls.Add(tb08);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(tb06);
            Controls.Add(tb04);
            Controls.Add(tb05);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(tb02);
            Controls.Add(tb03);
            Controls.Add(tb01);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label11);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(tbTotal);
            Controls.Add(tbCash);
            Controls.Add(tbChange);
            Controls.Add(button1);
            Controls.Add(rbDiscountFood);
            Controls.Add(rbDiscountBeverage);
            Controls.Add(oo);
            Controls.Add(pizza);
            Controls.Add(noodle);
            Controls.Add(grr);
            Controls.Add(coffee);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox3);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox coffee;
        private CheckBox grr;
        private CheckBox noodle;
        private CheckBox pizza;
        private CheckBox oo;
        private CheckBox rbDiscountBeverage;
        private CheckBox rbDiscountFood;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private MaskedTextBox tbGreenCoffeeQuantity;
        private MaskedTextBox tbGreenCoffeePrice;
        private MaskedTextBox tbCoffeeQuantity;
        private MaskedTextBox tbCoffeePrice;
        private MaskedTextBox tbPizzaQuantity;
        private MaskedTextBox tbPizzaPrice;
        private MaskedTextBox tbNoodleQuantity;
        private MaskedTextBox tbNoodlePrice;
        private MaskedTextBox tbDiscountFood;
        private MaskedTextBox tbDiscountBeverage;
        private MaskedTextBox tbDiscountAll;
        private Button button1;
        private MaskedTextBox tbChange;
        private MaskedTextBox tbCash;
        private MaskedTextBox tbTotal;
        private Label label1;
        private Label label3;
        private Label label11;
        private Label label2;
        private Label label4;
        private Label label5;
        private MaskedTextBox tb01;
        private MaskedTextBox tb03;
        private MaskedTextBox tb02;
        private Label label6;
        private Label label7;
        private Label label8;
        private MaskedTextBox tb05;
        private MaskedTextBox tb04;
        private MaskedTextBox tb06;
        private Label label9;
        private Label label10;
        private MaskedTextBox tb08;
        private MaskedTextBox tb07;
        private Label label14;
        private Label label13;
        private Label label12;
    }
}
